using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Module06_JWT_API.Models;
using System.Security.Claims;

namespace Module06_JWT_API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private static readonly List<Product> Products = new()
    {
        new Product { Id = 1, Name = "Laptop", Price = 450000m, Category = "Electronics" },
        new Product { Id = 2, Name = "Headphones", Price = 25000m, Category = "Accessories" }
    };

    private static int _nextId = 3;

    [HttpGet]
    [AllowAnonymous]
    public ActionResult<IEnumerable<Product>> GetAll()
    {
        return Ok(Products);
    }

    [HttpGet("{id:int}")]
    [AllowAnonymous]
    public ActionResult<Product> GetById(int id)
    {
        var product = Products.FirstOrDefault(p => p.Id == id);
        return product is null ? NotFound() : Ok(product);
    }

    [HttpPost]
    [Authorize]
    public ActionResult<Product> Create([FromBody] Product product)
    {
        if (string.IsNullOrWhiteSpace(product.Name) || string.IsNullOrWhiteSpace(product.Category))
            return BadRequest(new { message = "Name and Category are required." });

        product.Id = _nextId++;
        Products.Add(product);

        var username = HttpContext.User.Claims
            .FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

        return CreatedAtAction(nameof(GetById), new { id = product.Id }, new
        {
            product,
            createdBy = username
        });
    }

    [HttpDelete("{id:int}")]
    [Authorize]
    public IActionResult Delete(int id)
    {
        var product = Products.FirstOrDefault(p => p.Id == id);
        if (product is null)
            return NotFound();

        Products.Remove(product);
        return NoContent();
    }
}
