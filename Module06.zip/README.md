# Module 06 — JWT Protection for ASP.NET Core Web API

## Requirements
- .NET 8 SDK
- Visual Studio 2022 or `dotnet` CLI

## Run
1. Open `Module06_JWT_API.csproj` in Visual Studio, or open this folder in Visual Studio.
2. Restore NuGet packages and run the project.
3. Swagger opens at the local HTTPS/HTTP address shown in the console.

CLI:
```bash
dotnet restore
dotnet run
```

## Demo login
`POST /api/auth/login`
```json
{
  "username": "student",
  "password": "12345"
}
```
Copy the `token` from the response.

## Swagger checks
- `GET /api/products` — public, should return 200.
- `GET /api/products/1` — public, should return 200.
- `POST /api/products` without authorization — should return 401.
- `DELETE /api/products/1` without authorization — should return 401.
- Click **Authorize**, paste the token only (do not add `Bearer ` if Swagger asks for the token only).
- `POST /api/products` with authorization:
```json
{
  "id": 0,
  "name": "Keyboard",
  "price": 18000,
  "category": "Accessories"
}
```
- `DELETE /api/products/3` with authorization — deletes the new item if it was created as ID 3.
- Wrong credentials return 401. An invalid or expired token on protected endpoints returns 401.

## Demo limitations
Products are stored in memory and reset when the app restarts. The login uses fixed demo credentials only to satisfy the coursework; do not use this authentication design in production. The JWT key in `appsettings.json` is a coursework placeholder and must be replaced with a strong secret for real deployments.
